const MONGO_DB_CONFIG = {
  MONGO_URL: "mongodb+srv://shopshoes:shopshoes2023@ecommerceshop.ty9ulfh.mongodb.net/shopshoes",
  PAGE_SIZE: 10,
  PROJECTNAME: "SneakerZone",
  PORT: "3005",
  SECRET: "shopshoes2023",
  JWT_SECRET: "shopshoes2023",
  SMTP: "smtp.gmail.com",
  PORT_SMTP: 587,
  USERNAME_SMTP: "ycode2023@gmail.com",
  PASSWORD_SMTP: "vlbtbbssoviyaryh",
  DISPLAYNAME_SMTP: "SneakerZone",

};

module.exports = {
  MONGO_DB_CONFIG,
}